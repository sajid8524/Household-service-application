#include<stdio.h>
#include<stdlib.h>
    struct node
    {
        int data;
        struct node *next;
};
struct node* create(int value)
{
    struct node* nine = (struct node*)malloc(sizeof(struct node));
    nine->data=value;
    nine->next=NULL;
    return nine;
    
}

int main(){        
        struct node *head;
        struct node *one = (struct node*)malloc(sizeof(struct node));
        struct node *two = (struct node*)malloc(sizeof(struct node));
        struct node *three = (struct node*)malloc(sizeof(struct node));
        struct node *four = (struct node*)malloc(sizeof(struct node));
        struct node *five = (struct node*)malloc(sizeof(struct node));
        struct node *six = (struct node*)malloc(sizeof(struct node));
        struct node *seven = (struct node*)malloc(sizeof(struct node));
        struct node *eight = (struct node*)malloc(sizeof(struct node));
        head-> next=one;
        one->data = 1;
        one->next = two;
        two->data = 4;
        two->next = three;
        three->data = 8;
        three->next = four;
        four->data = 9;
        four->next =five ;
        five->data = 10;
        five->next = six;
        six->data = 3;
        six->next = seven ;
        seven->data = 5;
        seven->next = eight ;
        eight->data = 2;
        eight->next = NULL;
 while(head!=NULL)
 {
         printf("%d \n",head->data);
         head=head->next ;
   }
   return 0;
}       


    